package utng.edu.mx.notificacion

import utng.edu.mx.notificacion.NotificationCategory
import utng.edu.mx.notificacion.NotificationMessage

class NotificationRepository {
    private val availableMessages = listOf(
        NotificationMessage(
            id = 1,
            title = "¡Hora de brillar!",
            message = "Tu cerebro está listo para absorber conocimiento. ¡Dale una oportunidad! 🧠📚",
            emoji = "🌟",
            category = NotificationCategory.MOTIVATION
        ),
        NotificationMessage(
            id = 2,
            title = "¿Olvidaste tu estudio?",
            message = "¡Tu cerebro te está pidiendo ayuda! No lo dejes esperando 🧠📖",
            emoji = "🤔",
            category = NotificationCategory.REMINDER
        ),
        NotificationMessage(
            id = 3,
            title = "¡Pausa para el éxito!",
            message = "Unos minutos de estudio hoy = Un futuro brillante mañana ✨",
            emoji = "⏸️",
            category = NotificationCategory.MOTIVATION
        ),
        NotificationMessage(
            id = 4,
            title = "¡Alerta de genio!",
            message = "Tu yo del futuro te agradecerá este momento de estudio 🙏📘",
            emoji = "🚨",
            category = NotificationCategory.ACHIEVEMENT
        ),
    )

    fun getRandomMessage(): NotificationMessage {
        return availableMessages.random()
    }

    fun getMessagesByCategory(category: NotificationCategory): List<NotificationMessage> {
        return availableMessages.filter { it.category == category }
    }

    fun getAllMessages(): List<NotificationMessage> {
        return availableMessages
    }
}