package utng.edu.mx.notificacion

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

// ==================================================================
// ✅ CAMBIO REAL #1: ESTAS SON LAS LÍNEAS QUE FALTABAN
// ==================================================================
import utng.edu.mx.notificacion.ui.theme.NotificacionTheme

// ✅ LÍNEA CORRECTA

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                println("✅ Permiso de notificación CONCEDIDO")
            } else {
                println("❌ Permiso de notificación DENEGADO")
            }
        }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNotificationPermission()
        setContent {
            NotificacionTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    NotificationScreen()
                }
            }
        }
    }
}

@Composable
fun NotificationScreen() {
    val context = LocalContext.current

    // Gracias a los imports de arriba, estas líneas ahora son válidas
    val notificationManager: AppNotificationManager = remember(context) { AppNotificationManager(context) }
    val notificationHelper: NotificationHelper = remember(context) { NotificationHelper(context) }

    LaunchedEffect(Unit) {
        notificationHelper.createNotificationChannel()
    }

    var notificationCount by remember { mutableStateOf(0) }
    var selectedCategory by remember { mutableStateOf<NotificationCategory?>(null) }

    // Y como el tipo de 'notificationManager' es correcto, esta línea también es válida.
    val availableMessages = remember { notificationManager.getAvailableMessagesCount() }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "🧠 Notificaciones Inteligentes",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = "Elige tu tipo de motivación favorita",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(8.dp))

        // ==================================================================
        // ✅ CAMBIO REAL #2: SE AÑADE LA ANOTACIÓN FALTANTE
        // ==================================================================
        CategorySelector(
            selectedCategory = selectedCategory,
            onCategorySelected = { selectedCategory = it }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                // Todas estas llamadas ahora son válidas
                selectedCategory?.let { category ->
                    notificationManager.sendNotificationByCategory(category)
                } ?: run {
                    notificationManager.sendRandomNotification()
                }
                notificationCount++
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = MaterialTheme.shapes.medium
        ) {
            Text(
                text = selectedCategory?.let { "🚀 Enviar ${getCategoryName(it)}" } ?: "🎲 Sorpréndeme",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        StatsCard(
            notificationCount = notificationCount,
            availableMessages = availableMessages
        )

        TipCard()
    }
}

// ==================================================================
// ✅ CAMBIO REAL #3: SE AÑADEN LAS ANOTACIONES PARA MATERIAL 3
// ==================================================================
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CategorySelector(
    selectedCategory: NotificationCategory?,
    onCategorySelected: (NotificationCategory?) -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Categorías:", style = MaterialTheme.typography.titleSmall)
        Spacer(modifier = Modifier.height(12.dp))

        // Esta es la versión de FlowRow de Material 3, por eso requiere la anotación
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CategoryChip(
                label = "🎲 Todas",
                isSelected = selectedCategory == null,
                onClick = { onCategorySelected(null) }
            )

            NotificationCategory.values().forEach { category ->
                CategoryChip(
                    label = "${getCategoryEmoji(category)} ${getCategoryName(category)}",
                    isSelected = selectedCategory == category,
                    onClick = { onCategorySelected(category) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelLarge) }
    )
}

@Composable
fun StatsCard(notificationCount: Int, availableMessages: Int) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(20.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatItem(icon = "📤", value = "$notificationCount", label = "Enviadas")
            Divider(modifier = Modifier.height(60.dp).width(1.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            StatItem(icon = "💬", value = "$availableMessages", label = "Disponibles")
        }
    }
}

@Composable
fun StatItem(icon: String, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 24.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun TipCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("💡", fontSize = 28.sp, modifier = Modifier.padding(end = 12.dp))
            Column {
                Text("¿Sabías qué?", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Puedes personalizar los mensajes y categorías en tu `NotificationRepository`.", style = MaterialTheme.typography.bodySmall, lineHeight = 16.sp)
            }
        }
    }
}

fun getCategoryName(category: NotificationCategory): String = when (category) {
    NotificationCategory.REMINDER -> "Recordatorio"
    NotificationCategory.MOTIVATION -> "Motivación"
    NotificationCategory.ACHIEVEMENT -> "Logro"
    NotificationCategory.WARNING -> "Advertencia"
    NotificationCategory.TIP -> "Consejo"
}

fun getCategoryEmoji(category: NotificationCategory): String = when (category) {
    NotificationCategory.REMINDER -> "⏰"
    NotificationCategory.MOTIVATION -> "💪"
    NotificationCategory.ACHIEVEMENT -> "🏆"
    NotificationCategory.WARNING -> "⚠️"
    NotificationCategory.TIP -> "💡"
}
