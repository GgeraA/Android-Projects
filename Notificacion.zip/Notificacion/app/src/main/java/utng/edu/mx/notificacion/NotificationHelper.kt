// En el archivo NotificationHelper.kt
package utng.edu.mx.notificacion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "high_priority_channel"

        // ✅ AÑADE AQUÍ TUS IDs DE NOTIFICACIÓN CONSTANTES
        const val RICH_NOTIFICATION_ID = 1001
        // Puedes añadir más si los necesitas
    }

    fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Notificaciones de Alta Prioridad"
            val descriptionText = "Canal para notificaciones importantes."
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}