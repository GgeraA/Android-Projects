package utng.edu.mx.notificacion

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * 🚀 AppNotificationManager - Versión Refactorizada
 *
 * Gestiona el envío de diferentes tipos de notificaciones y organiza
 * la obtención de datos a través de un Repositorio.
 */
class AppNotificationManager(private val context: Context) {

    private val repository = NotificationRepository()
    fun sendRandomNotification() {
        val message = repository.getRandomMessage()
        sendNotification(message)
    }

    fun sendRichNotification() {
        if (!checkNotificationPermission()) {
            println("⚠️ No hay permiso para enviar notificaciones")
            return
        }

        val studyIntent = Intent(context, StudyActivity::class.java)
        val studyPendingIntent = PendingIntent.getActivity(context, 0, studyIntent, PendingIntent.FLAG_IMMUTABLE)

        val snoozeIntent = Intent(context, SnoozeReceiver::class.java)
        val snoozePendingIntent = PendingIntent.getBroadcast(context, 1, snoozeIntent, PendingIntent.FLAG_IMMUTABLE)

        val bitmap = try {
            BitmapFactory.decodeResource(context.resources, R.drawable.ic_launcher_foreground)
        } catch (e: Exception) {
            null
        }

        val notificationBuilder = NotificationCompat.Builder(context, NotificationHelper.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("¡Es hora de estudiar! 📚")
            .setContentText("Tu cerebro te está esperando")
            .addAction(R.drawable.ic_launcher_foreground, "📖 Estudiar Ahora", studyPendingIntent)
            .addAction(R.drawable.ic_launcher_foreground, "⏰ En 15 min", snoozePendingIntent)

        if (bitmap != null) {
            notificationBuilder
                .setLargeIcon(bitmap)
                .setStyle(
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(bitmap)
                )
        }

        try {
            NotificationManagerCompat.from(context).notify(1001, notificationBuilder.build())
            println("✅ ¡Notificación enriquecida enviada exitosamente!")
        } catch (e: SecurityException) {
            println("❌ Error: No se pudo enviar la notificación - ${e.message}")
        }

    }

    fun sendNotificationByCategory(category: NotificationCategory) {
        // .randomOrNull() para evitar crash si no hay mensajes de esa categoría
        repository.getMessagesByCategory(category).randomOrNull()?.let { message ->
            sendNotification(message)
        }
    }

    fun getAvailableMessagesCount(): Int {
        return repository.getAllMessages().size
    }

    private fun sendNotification(notificationMessage: NotificationMessage) {
        if (!checkNotificationPermission()) {
            println("⚠️ No hay permiso para enviar notificaciones")
            return
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            // ¡Buena práctica! Pasamos info extra a la Activity.
            putExtra("notification_id", notificationMessage.id)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationMessage.id, // Usar un request code único por notificación
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val fullTitle = "${notificationMessage.emoji} ${notificationMessage.title}"

        val notification = NotificationCompat.Builder(context, NotificationHelper.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(fullTitle)
            .setContentText(notificationMessage.message)
            .setPriority(notificationMessage.priority)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setStyle(NotificationCompat.BigTextStyle().bigText(notificationMessage.message))
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationMessage.id, notification)
            println("✅ ¡Notificación enviada exitosamente! ID: ${notificationMessage.id}")
        } catch (e: SecurityException) {
            println("❌ Error: No se pudo enviar la notificación - ${e.message}")
        }
    }

    /**
     * 🔍 Verifica si tenemos permiso para enviar notificaciones (Android 13+).
     */
    private fun checkNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }
}