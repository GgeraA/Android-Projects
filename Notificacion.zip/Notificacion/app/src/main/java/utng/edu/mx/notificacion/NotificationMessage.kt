package utng.edu.mx.notificacion

import androidx.core.app.NotificationCompat

data class NotificationMessage(
    val id: Int,
    val title: String,
    val message: String,
    val emoji: String,
    val priority: Int = NotificationCompat.PRIORITY_HIGH,
    val category: NotificationCategory
)

/**
 * 🏷️ Categorías de notificaciones
 * 
 * Diferentes "sabores" de notificaciones, como los sabores de helado 🍦
 */
enum class NotificationCategory {
    REMINDER,      // Recordatorios gentiles
    MOTIVATION,    // Mensajes motivadores
    ACHIEVEMENT,   // Logros desbloqueados
    WARNING,       // Advertencias importantes
    TIP           // Consejos útiles
}