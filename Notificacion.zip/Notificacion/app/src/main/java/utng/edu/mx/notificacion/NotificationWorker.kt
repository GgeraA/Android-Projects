package utng.edu.mx.notificacion

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class NotificationWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {

    // Instancia del repositorio
    private val notificationRepository = NotificationRepository()

    override fun doWork(): Result {
        // Obtener el contexto de la aplicación
        val context = applicationContext

        // Crear el canal de notificación (es seguro llamarlo varias veces)
        NotificationHelper.createNotificationChannel(context)

        // Enviar la notificación usando el repositorio
        val notificationManager = AppNotificationManager(context)
        val randomMessage = notificationRepository.getRandomMessage()
        notificationManager.sendMotivationalNotification(randomMessage)

        // Indicar que el trabajo se completó con éxito
        return Result.success()
    }
}

private fun AppNotificationManager.sendMotivationalNotification(randomMessage: Any) {}

private fun NotificationRepository.getRandomMessage() {
    TODO("Not yet implemented")
}

private fun NotificationHelper.Companion.createNotificationChannel(context: Context) {}
