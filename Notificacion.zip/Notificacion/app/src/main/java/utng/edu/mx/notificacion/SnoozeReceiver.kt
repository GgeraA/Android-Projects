package utng.edu.mx.notificacion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class SnoozeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Aquí puedes reprogramar la notificación para 15 minutos más tarde
        // Por ahora, solo mostraremos un mensaje en el log
        Log.d("SnoozeReceiver", "Notificación pospuesta por 15 minutos.")
    }
}