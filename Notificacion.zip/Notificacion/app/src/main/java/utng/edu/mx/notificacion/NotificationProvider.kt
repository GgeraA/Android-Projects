package utng.edu.mx.notificacion

object NotificationProvider {

    private var messageIdCounter = 0

    private val motivationalMessages = listOf(
        NotificationMessage(
            id = ++messageIdCounter,
            title = "¡Hora de brillar!",
            message = "Tu cerebro está listo para absorber conocimiento. ¡Dale una oportunidad!",
            emoji = "🌟",
            category = NotificationCategory.MOTIVATION
        ),
        NotificationMessage(
            id = ++messageIdCounter,
            title = "¿Olvidaste tu estudio?",
            message = "¡Tu cerebro te está pidiendo ayuda! No lo dejes esperando.",
            emoji = "🤔",
            category = NotificationCategory.REMINDER
        ),
        NotificationMessage(
            id = ++messageIdCounter,
            title = "¡Pausa para el éxito!",
            message = "Unos minutos de estudio hoy = Un futuro brillante mañana.",
            emoji = "⏸️",
            category = NotificationCategory.MOTIVATION
        ),
        NotificationMessage(
            id = ++messageIdCounter,
            title = "¡Alerta de genio!",
            message = "Tu yo del futuro te agradecerá este momento de estudio.",
            emoji = "🚨",
            category = NotificationCategory.ACHIEVEMENT
        )
    )

    fun getRandomMotivationalMessage(): NotificationMessage {
        return motivationalMessages.random()
    }
}