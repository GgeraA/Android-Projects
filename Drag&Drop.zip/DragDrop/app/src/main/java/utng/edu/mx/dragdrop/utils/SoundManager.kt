package utng.edu.mx.dragdrop.utils

import android.content.Context
import android.media.MediaPlayer
import androidx.annotation.RawRes

/**
 * Gestor de sonidos para feedback auditivo.
 *
 * Pedagogía: El sonido refuerza el aprendizaje.
 * - Sonido alegre al acertar
 * - Sonido suave al fallar (sin ser negativo)
 */
class SoundManager(private val context: Context) {

    private var correctPlayer: MediaPlayer? = null
    private var incorrectPlayer: MediaPlayer? = null

    fun init(@RawRes correctSound: Int, @RawRes incorrectSound: Int) {
        correctPlayer = MediaPlayer.create(context, correctSound)
        incorrectPlayer = MediaPlayer.create(context, incorrectSound)
    }

    fun playCorrect() {
        correctPlayer?.start()
    }

    fun playIncorrect() {
        incorrectPlayer?.start()
    }

    fun release() {
        correctPlayer?.release()
        incorrectPlayer?.release()
        correctPlayer = null
        incorrectPlayer = null
    }
}