package utng.edu.mx.dragdrop.ui

import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize

/**
 * Estado para gestionar Drag and Drop.
 *
 * Analogía: Como un GPS que rastrea dónde está tu dedo
 * y qué elemento estás arrastrando en tiempo real.
 */
@Stable
class DragAndDropState {
    var isDragging by mutableStateOf(false)
        private set

    var dragPosition by mutableStateOf(Offset.Zero)
        private set

    var draggedItemId by mutableStateOf<Int?>(null)
        private set

    var draggedItemSize by mutableStateOf(IntSize.Zero)
        private set

    fun startDragging(itemId: Int, size: IntSize, position: Offset) {
        isDragging = true
        draggedItemId = itemId
        draggedItemSize = size
        dragPosition = position
    }

    fun updateDragPosition(position: Offset) {
        dragPosition = position
    }

    fun stopDragging() {
        isDragging = false
        draggedItemId = null
    }
}

@Composable
fun rememberDragAndDropState(): DragAndDropState {
    return remember { DragAndDropState() }
}