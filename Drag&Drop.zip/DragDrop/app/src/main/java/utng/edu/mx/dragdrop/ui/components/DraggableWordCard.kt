package utng.edu.mx.dragdrop.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import utng.edu.mx.dragdrop.data.Word

/**
 * Tarjeta de palabra que puede ser arrastrada.
 *
 * Analogía: Como una tarjeta física que el niño puede tomar
 * con su dedo y mover por la pantalla.
 *
 * Características profesionales:
 * - Feedback visual inmediato (la tarjeta se eleva al tocarla)
 * - Animaciones suaves
 * - Accesibilidad para niños pequeños (tamaños grandes, colores claros)
 */
@Composable
fun DraggableWordCard(
    word: Word,
    isMatched: Boolean,
    isDragging: Boolean,
    onDragStart: (Offset, IntSize) -> Unit,
    onDragEnd: () -> Unit,
    onDrag: (Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    // Estado para animaciones
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed || isDragging) 1.1f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale_animation"
    )

    val elevation by animateDpAsState(
        targetValue = if (isPressed || isDragging) 12.dp else 4.dp,
        label = "elevation_animation"
    )

    // Posición para tracking
    var cardPosition by remember { mutableStateOf(Offset.Zero) }
    var cardSize by remember { mutableStateOf(IntSize.Zero) }

    /**
     * AnimatedVisibility: Hace que la tarjeta desaparezca suavemente
     * cuando se empareja correctamente.
     *
     * Como cuando una tarjeta de juego "desaparece" con efecto mágico.
     */
    AnimatedVisibility(
        visible = !isMatched,
        exit = fadeOut() + scaleOut()
    ) {
        Card(
            modifier = modifier
                .size(width = 140.dp, height = 80.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .onGloballyPositioned { coordinates ->
                    // Captura la posición y tamaño del elemento
                    cardPosition = coordinates.positionInRoot()
                    cardSize = coordinates.size
                }
                .pointerInput(word.id) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            isPressed = true
                            onDragStart(cardPosition + offset, cardSize)
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            onDrag(dragAmount)
                        },
                        onDragEnd = {
                            isPressed = false
                            onDragEnd()
                        },
                        onDragCancel = {
                            isPressed = false
                            onDragEnd()
                        }
                    )
                },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = elevation)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = word.text,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}