package utng.edu.mx.dragdrop.utils

import android.R
import android.content.Context
import androidx.annotation.DrawableRes

object ImageHelper {

    /**
     * Obtiene el ID del recurso drawable de forma segura.
     * Si no encuentra la imagen, devuelve un placeholder.
     */
    @DrawableRes
    fun getImageResourceId(context: Context, imageName: String): Int {
        // Intenta obtener el recurso
        val resourceId = context.resources.getIdentifier(
            imageName,
            "drawable",
            context.packageName
        )

        // Si no existe, usa un placeholder del sistema
        return if (resourceId != 0) {
            resourceId
        } else {
            // Usar icono del sistema como fallback
            R.drawable.ic_menu_gallery
        }
    }

    /**
     * Verifica si un recurso drawable existe
     */
    fun drawableExists(context: Context, imageName: String): Boolean {
        val resourceId = context.resources.getIdentifier(
            imageName,
            "drawable",
            context.packageName
        )
        return resourceId != 0
    }
}