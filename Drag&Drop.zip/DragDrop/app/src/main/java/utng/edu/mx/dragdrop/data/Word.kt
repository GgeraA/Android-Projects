package utng.edu.mx.dragdrop.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidad que representa una palabra del método Doman.
 *
 * Analogía: Es como una ficha de inventario en una tienda.
 * Cada palabra tiene su identificador único, el texto,
 * la categoría y la URL de su imagen.
 */
@Entity(tableName = "words")
data class Word(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val text: String,           // Ejemplo: "MAMÁ"
    val category: String,       // Ejemplo: "familia", "animales", "colores"
    val imageUrl: String,       // URL o nombre del recurso drawable
    val difficulty: Int = 1     // 1=fácil, 2=medio, 3=difícil
)