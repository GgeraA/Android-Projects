package utng.edu.mx.dragdrop.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Pantalla de resultados con animaciones motivadoras.
 *
 * Pedagogía: Siempre muestra refuerzo positivo, incluso con errores.
 * "¡Muy bien! Acertaste 3 de 4" en lugar de "Fallaste 1".
 */
@Composable
fun ResultsScreen(
    correctCount: Int,
    totalCount: Int,
    onPlayAgain: () -> Unit,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val percentage = (correctCount.toFloat() / totalCount * 100).roundToInt()

    // Mensaje motivador según rendimiento
    val (message, emoji, color) = when {
        percentage == 100 -> Triple("¡Perfecto!", "🌟", Color(0xFFFFD700))
        percentage >= 75 -> Triple("¡Excelente!", "😊", Color(0xFF4CAF50))
        percentage >= 50 -> Triple("¡Muy bien!", "👍", Color(0xFF2196F3))
        else -> Triple("¡Sigue practicando!", "💪", Color(0xFFFF9800))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Emoji animado
        var visible by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            visible = true
        }

        AnimatedVisibility(
            visible = visible,
            enter = scaleIn(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            ) + fadeIn()
        ) {
            Text(
                text = emoji,
                fontSize = 120.sp,
                modifier = Modifier.padding(bottom = 24.dp)
            )
        }

        // Mensaje
        Text(
            text = message,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Gráfico circular animado
        AnimatedCircularProgress(
            percentage = percentage,
            color = color,
            modifier = Modifier.size(200.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Estadísticas
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatRow(
                    icon = Icons.Filled.CheckCircle,
                    label = "Respuestas correctas",
                    value = correctCount.toString(),
                    color = Color(0xFF4CAF50)
                )

                StatRow(
                    icon = Icons.Filled.Close,
                    label = "Respuestas incorrectas",
                    value = (totalCount - correctCount).toString(),
                    color = Color(0xFFF44336)
                )

                Divider()

                StatRow(
                    icon = Icons.Filled.Star,
                    label = "Puntuación",
                    value = "$percentage%",
                    color = color
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Botones
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onExit,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Home, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Salir")
            }

            Button(
                onClick = onPlayAgain,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = color
                )
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Jugar otra vez")
            }
        }
    }
}

@Composable
private fun StatRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = label,
                fontSize = 16.sp
            )
        }

        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

/**
 * Gráfico circular con animación de relleno progresivo.
 *
 * Técnica: Usa Canvas para dibujar arcos personalizados.
 * La animación empieza en 0° y progresa hasta el porcentaje final.
 */
@Composable
private fun AnimatedCircularProgress(
    percentage: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    var animatedPercentage by remember { mutableStateOf(0f) }

    LaunchedEffect(percentage) {
        animate(
            initialValue = 0f,
            targetValue = percentage.toFloat(),
            animationSpec = tween(
                durationMillis = 1500,
                easing = FastOutSlowInEasing
            )
        ) { value, _ ->
            animatedPercentage = value
        }
    }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 20.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val radius = diameter / 2

            // Círculo de fondo (gris claro)
            drawArc(
                color = Color.LightGray.copy(alpha = 0.3f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                size = Size(diameter, diameter)
            )

            // Arco de progreso (color dinámico)
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = (animatedPercentage / 100) * 360f,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                size = Size(diameter, diameter)
            )
        }

        // Texto central
        Text(
            text = "${animatedPercentage.roundToInt()}%",
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}