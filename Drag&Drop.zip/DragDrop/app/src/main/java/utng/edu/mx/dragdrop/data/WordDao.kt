package utng.edu.mx.dragdrop.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * DAO: Define las operaciones que podemos hacer con la base de datos.
 *
 * Analogía: Es como el catálogo de servicios de un banco.
 * Puedes "depositar" (insert), "consultar saldo" (getAll),
 * "retirar" (delete), etc.
 */
@Dao
interface WordDao {

    // Flow emite datos en tiempo real, como WhatsApp muestra mensajes nuevos
    @Query("SELECT * FROM words ORDER BY category, text")
    fun getAllWords(): Flow<List<Word>>

    @Query("SELECT * FROM words WHERE category = :category")
    fun getWordsByCategory(category: String): Flow<List<Word>>

    @Query("SELECT * FROM words WHERE difficulty = :level")
    fun getWordsByDifficulty(level: Int): Flow<List<Word>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWord(word: Word)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(words: List<Word>)

    @Delete
    suspend fun deleteWord(word: Word)

    @Query("DELETE FROM words")
    suspend fun deleteAllWords()
}