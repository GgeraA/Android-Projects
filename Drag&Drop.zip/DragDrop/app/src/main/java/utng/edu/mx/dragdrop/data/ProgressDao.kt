package utng.edu.mx.dragdrop.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {

    @Query("SELECT * FROM child_progress WHERE childName = :name ORDER BY attemptDate DESC")
    fun getProgressByChild(name: String): Flow<List<ChildProgress>>

    @Query("""
        SELECT * FROM child_progress 
        WHERE childName = :name 
        AND attemptDate >= :startDate 
        ORDER BY attemptDate DESC
    """)
    fun getRecentProgress(name: String, startDate: Long): Flow<List<ChildProgress>>

    // Estadísticas: Porcentaje de aciertos
    @Query("""
        SELECT 
            COUNT(CASE WHEN isCorrect = 1 THEN 1 END) * 100.0 / COUNT(*) as percentage
        FROM child_progress 
        WHERE childName = :name
    """)
    suspend fun getSuccessRate(name: String): Double?

    @Insert
    suspend fun insertProgress(progress: ChildProgress)

    @Query("DELETE FROM child_progress WHERE childName = :name")
    suspend fun deleteProgressByChild(name: String)
}